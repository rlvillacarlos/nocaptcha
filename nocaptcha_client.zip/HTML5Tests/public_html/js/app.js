angular.module('myApp',[])

.controller('myController',function($timeout,$scope){
    $scope.nocaptcha;
   
    $noCAPTCHA.requireCAPTCHA(function(state){
        alert('Yipee! No need for CAPTCHA. You still have ' + 
                state.remaining + " of " + state.quota);
        $timeout(function(){
            $scope.nocaptcha=true;
        },0);
    },function(failure){
        alert('Boo! Bot or not bot? That is the question. \Reason for failure is: ' 
                + failure.reason.text);
        $timeout(function(){
            $scope.nocaptcha=false;
        },0);
    });    
})

